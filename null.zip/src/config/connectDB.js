const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'qgtfjjnv_win',
    password: 'qgtfjjnv_win',
    database: 'qgtfjjnv_win'
});


export default connection;